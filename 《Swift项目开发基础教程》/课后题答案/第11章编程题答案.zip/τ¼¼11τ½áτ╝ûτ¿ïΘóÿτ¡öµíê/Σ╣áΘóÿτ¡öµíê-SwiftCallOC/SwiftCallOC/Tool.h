//
//  Tool.h
//  SwiftCallOC
//
//  Created by itcast on 16/1/29.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Tool : NSObject
+ (int) getSum:(int)firstValue andInt:(int)intValue;
@end
