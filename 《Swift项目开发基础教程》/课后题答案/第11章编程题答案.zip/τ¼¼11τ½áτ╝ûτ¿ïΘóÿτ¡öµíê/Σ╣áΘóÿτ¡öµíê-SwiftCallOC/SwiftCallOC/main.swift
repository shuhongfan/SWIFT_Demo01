//
//  main.swift
//  SwiftCallOC
//
//  Created by itcast on 16/1/29.
//  Copyright © 2016年 itcast. All rights reserved.
//

import Foundation

let result = Tool.getSum(12, andInt: 13)
print(result)

