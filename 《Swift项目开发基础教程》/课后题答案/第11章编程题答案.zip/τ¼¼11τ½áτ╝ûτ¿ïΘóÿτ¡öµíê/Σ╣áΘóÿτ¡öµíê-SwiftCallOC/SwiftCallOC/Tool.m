//
//  Tool.m
//  SwiftCallOC
//
//  Created by itcast on 16/1/29.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "Tool.h"

@implementation Tool
+ (int) getSum:(int)firstValue andInt:(int)intValue
{
    return firstValue + intValue;
}
@end
